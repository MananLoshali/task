import { createSlice } from "@reduxjs/toolkit"

interface User {
    token: string
}

const initialState: User = {
    token: ""
}

export const userSlice = createSlice({
    name: "user",
    initialState: initialState,
    reducers: {
        setUser: (state, action) => {
            state.token = action.payload;
            return state;
        },
        deleteUser: (state, action) => {
            state = initialState;
            return state;
        }
    }
})

export const { setUser, deleteUser } = userSlice.actions
export default userSlice.reducer
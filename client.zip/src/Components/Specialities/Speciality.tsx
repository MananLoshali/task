import style from "./special.module.css";

const Speciality = () => {
  const special = [
    {
      type: "Experienced",
      img: "el1.png",
      desc: "Our experience of 25 years of building and making achievements in the world of development",
    },
    {
      type: "Competitive price",
      img: "el2.png",
      desc: "Our experience of 25 years of building and making achievements in the world of development",
    },
    {
      type: "On time",
      img: "el3.png",
      desc: " We prioritize the quality of our work and finish it on time",
    },
    {
      type: "Best Materials",
      img: "el4.png",
      desc: "The material determines the building itself so we recommend that you use  the best & quality materials  in its class.",
    },
  ];

  return (
    <div className={style.container} id="portfolio">
      <div className={style.upper}>
        <h3 className={style.heading}>What Make Us Different?</h3>
        <p className={style.para}>
          Check out our best service you can possibly orders in building your
          company and don't forget to ask via our email or our customer service
          if you are interested in using our services
        </p>
      </div>
      <div className={style.lower}>
        {special.map((item) => (
          <div className={style.wrapper}>
            <img className={style.img} src={item.img} alt="" />
            <h2 className={style.headings}>{item.type}</h2>
            <p className={style.desc}>{item.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Speciality;

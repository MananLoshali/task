import { link } from "fs";
import style from "./footer.module.css";
import { Link } from "react-router-dom";

const Footer = () => {
  const icons = [
    { img: "icon1.png", link: "/linkedin" },
    { img: "icon2.png", link: "/google" },
    { img: "icon3.png", link: "/instagram" },
    { img: "icon4.png", link: "/twitter" },
  ];

  const company = [
    { text: "About", link: "/about" },
    { text: "How it Works", link: "/howitworks" },
    { text: "Term", link: "/term" },
    { text: "Privacy Policy", link: "/privacypolicy" },
  ];

  const more = [
    { text: "Documentation", link: "/documentation" },
    { text: "License", link: "/license" },
  ];

  return (
    <div className={style.container}>
      <div className={style.left}>
        <div className={style.wrapper}>
          <div className={style.inner}>
            <h1 className={style.heading}>Logo</h1>
            <p className={style.para}>
              is a general contractor company based in Jakarta. More than 25
              years of experience in building and carving out Indonesia's
              development.
            </p>
          </div>
          <div className={style.btn_container}>
            {icons.map((item) => (
              <Link style={{ textDecoration: "none" }} to={item.link}>
                <img className={style.img} src={item.img} alt="" />
              </Link>
            ))}
          </div>
        </div>
      </div>
      <div className={style.right}>
        <div className={style.rwrapper}>
          <div className={style.ileft}>
            <p className={style.ipara}>Company</p>
            <div className={style.link_wrapper}>
              {company.map((item) => (
                <Link className={style.link} to={item.link}>
                  {item.text}
                </Link>
              ))}
            </div>
          </div>
          <div className={style.iright}>
            <p className={style.ipara}>More</p>
            <div className={style.link_wrapper}>
              {more.map((item) => (
                <Link className={style.link} to={item.link}>
                  {item.text}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;

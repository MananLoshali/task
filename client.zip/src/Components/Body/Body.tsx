import style from "./body.module.css";

const Body = () => {
  return (
    <div className={style.container}>
      <div className={style.left_container}>
        <div className={style.heading_container}>
          <p className={style.heading}>We Provide</p>
          <p className={style.heading}>Architectural design</p>
          <p className={style.heading}>and Construction</p>
        </div>
        <div className={style.para_container}>
          <p className={style.para}>
            ​More than 100 building and housing projects that we have built. The
            building owner chose us over other contractors in Jakarta, because
            our work is different
          </p>
        </div>
        <div className={style.btn_contianer}>
          <button className={style.button}>Discover More</button>
        </div>
        <div className={style.bottom_container}>
          <div className={style.wrapper}>
            <p className={style.upper}>300+</p>
            <p className={style.lower}>Happy Clients</p>
          </div>
          <div className={style.wrapper}>
            <p className={style.upper}>900+</p>
            <p className={style.lower}>Amazing Projects</p>
          </div>
          <div className={style.wrapper}>
            <p className={style.upper}>20+</p>
            <p className={style.lower}>Awards Winning</p>
          </div>
        </div>
      </div>
      <div className={style.right_container}>
        <div className={style.img_container}>
          <img className={style.img} src="home.png" alt="Home image" />
        </div>
        <div className={style.bottom}>
          <div className={style.left}>
            <p className={style.upper}>General</p>
            <p className={style.lower}>Project</p>
          </div>
          <div className={style.middle}></div>
          <div className={style.right}>
            <p className={style.parab}>
              As a trusted general project that has been operating for 25 years,
              our commitment is always to prioritize our client satisfaction
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Body;

import Button from "../Button/Button";
import style from "./navbar.module.css";
import { Link } from "react-scroll";

const Navbar = () => {
  const links = [
    {
      name: "Home",
      link: "home",
    },
    {
      name: "Services",
      link: "services",
    },
    {
      name: "Find a Team",
      link: "findateam",
    },
    {
      name: "About us",
      link: "about",
    },
    {
      name: "Articles",
      link: "articles",
    },
    {
      name: "Portfolio",
      link: "portfolio",
    },
    {
      name: "Contact us",
      link: "contactus",
    },
  ];

  return (
    <div className={style.container}>
      <div className={style.left_container}>
        <h1 className={style.heading}>Logo</h1>
      </div>
      <div className={style.right_container}>
        <ul className={style.list}>
          {links.map((item) => (
            <Link
              className={style.list_item}
              to={item.link}
              spy={true}
              smooth={true}
              offset={-90}
              duration={700}
            >
              {item.name}
            </Link>
            // <li className={style.list_item}>{item.name}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Navbar;

import { FormEvent, useState } from "react";
import Button from "../../Components/Button/Button";
import Input from "../../Components/Input/Input";
import style from "./register.module.css";
import { Link, useNavigate } from "react-router-dom";
import { useRegisterMutation } from "../../services/api";

const Register = () => {
  const [registerUser] = useRegisterMutation();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<any>();

  const handleClick = async (e: FormEvent) => {
    e.preventDefault();
    console.log(username, email, password);
    try {
      const payload = await registerUser({
        username,
        email,
        password,
      }).unwrap();
      console.log("fulfilled", payload);
      navigate("/login");
    } catch (error) {
      console.log(error);
      setErr(error);
    }
  };

  return (
    <div className={style.container}>
      <h1 className={style.heading}>REGISTER</h1>
      <form onSubmit={(e) => handleClick(e)} className={style.form}>
        <Input
          type="text"
          placeholder="Enter the username"
          setname={setUsername}
        />
        <Input type="email" placeholder="Enter the email" setname={setEmail} />
        <Input
          type="password"
          placeholder="Enter the password"
          setname={setPassword}
        />
        <Button type="Register" />
        <p>
          Already a user <Link to="/login">Login</Link>
        </p>
      </form>
      {err && <p>Something went wrong. Try again...</p>}
    </div>
  );
};

export default Register;

import mongoose from "mongoose";

const propertySchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: String,
    address: String,
    city: String,
    state: String,
    country: String,
    price: Number,
    bedrooms: Number,
    bathrooms: Number,
    area: Number,
    yearBuilt: Number,
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    listingDate: { type: Date, default: Date.now },
})

const Property = mongoose.model("property", propertySchema)
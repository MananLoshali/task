import style from "./collection.module.css";

const Collection = () => {
  const collection = [
    { img: "col1.png" },
    { img: "col2.png" },
    { img: "col3.png" },
    { img: "col4.png" },
  ];
  return (
    <div className={style.container}>
      <h1 className={style.heading}>Our collection best project</h1>
      <div className={style.inner}>
        {collection.map((item) => (
          <div className={style.wrapper}>
            <img src={item.img} alt="" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Collection;

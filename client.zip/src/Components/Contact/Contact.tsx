import style from "./contact.module.css";

const Contact = () => {
  return (
    <div className={style.container} id="findateam">
      <div className={style.left}>
        <img className={style.img} src="house2.png" alt="" />
      </div>
      <div className={style.middle}>
        <img className={style.user_img} src="uimg.png" alt="" />
      </div>
      <div className={style.right}>
        <div className={style.wrapper}>
          <h1 className={style.heading}>
            Meet and talk with our best architecture
          </h1>
          <p className={style.para}>
            All our teams are professional and competent in their fields and
            will help you realize your dream building with the excellent result.
          </p>
          <div className={style.inner_wrapper}>
            <button className={style.btn}>See all item</button>
            <p className={style.paras}>How it works</p>
            <img className={style.aimg} src="arrow.png" alt="" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;

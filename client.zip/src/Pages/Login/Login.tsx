import { FormEvent, useState } from "react";
import Button from "../../Components/Button/Button";
import Input from "../../Components/Input/Input";
import style from "./login.module.css";
import { Link, useNavigate } from "react-router-dom";
import { useLoginMutation } from "../../services/api";
import { useAppDispatch } from "../../store/store";
import { setUser } from "../../store/reducers/userReducer";

const Login = () => {
  const [loginUser] = useLoginMutation();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<any>();

  const dispatch: any = useAppDispatch();

  const handleClick = async (e: FormEvent) => {
    e.preventDefault();
    console.log(email, password);
    try {
      const payload = await loginUser({
        email,
        password,
      }).unwrap();
      console.log("fulfilled", payload);
      dispatch(setUser(payload.token));
      navigate("/");
    } catch (error) {
      console.log(error);
      setErr(error);
    }
  };

  return (
    <div className={style.container}>
      <h1 className={style.heading}>LOGIN</h1>
      <form onSubmit={(e) => handleClick(e)} className={style.form}>
        <Input type="email" placeholder="Enter the email" setname={setEmail} />
        <Input
          type="password"
          placeholder="Enter the password"
          setname={setPassword}
        />
        <Button type="Login" />
        <p>
          New user <Link to="/register">Register</Link>
        </p>
        {err && <p>Something went wrong. Try again....</p>}
      </form>
    </div>
  );
};

export default Login;

import { Request, Response } from "express"
import { User } from "../model/User";
import bcrypt from "bcryptjs"

export const register = async (req: Request, res: Response) => {

    const { username, email, password } = req.body;
    console.log(username, email, password);

    try {
        const user = await User.findOne({ email: email });

        if (user) {
            return res.status(400).json({ msg: "User already exists" })
        }

        if (!username || !email || !password) {
            return res.status(400).json({ msg: "All fields are necessary" })
        }

        const hashedPassword = await bcrypt.hash(password, 5);

        const newUser = new User({
            username: username,
            email: email,
            password: hashedPassword
        })

        const savedUser = await newUser.save();
        res.status(201).json({ msg: "User created successfull", user: savedUser })

    } catch (error) {
        console.log(error);
        res.status(500).json({ msg: "Internal server error" });
    }
}
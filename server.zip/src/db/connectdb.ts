import mongoose from "mongoose";



export const connectDB: (MONGOURI: string) => Promise<void> = async (MONGOURI: string) => {
    try {
        await mongoose.connect(MONGOURI);
        console.log("DB connected successfully");

    } catch (error) {
        console.log("Error while connecting", error);

    }

}
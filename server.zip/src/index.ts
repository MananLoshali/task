import express, { Express } from "express";
import dotenv from "dotenv";
import path from "path";
import cors from "cors";
import { connectDB } from "./db/connectdb";
import authRoute from "./routes/authRoute"

const app: Express = express();

dotenv.config({ path: path.join(__dirname, ".env") });

const PORT = process.env.PORT;
const MONGOURI = process.env.MONGO_DB_URI || "";


app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());


connectDB(MONGOURI);

app.use("/api/v1/auth", authRoute);

app.listen(PORT, () => {
    console.log(`server listening ${PORT}`);

})
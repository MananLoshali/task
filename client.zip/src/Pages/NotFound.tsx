import React from "react";
import { Link } from "react-router-dom";

const NotFound = () => {
  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        gap: "20px",
      }}
    >
      <p style={{ fontFamily: "sans-serif", fontSize: "66px", color: "brown" }}>
        404 NOT FOUND
      </p>
      <p style={{ fontSize: "24px", cursor: "pointer" }}>
        Go Back <Link to="/">Home</Link>
      </p>
    </div>
  );
};

export default NotFound;

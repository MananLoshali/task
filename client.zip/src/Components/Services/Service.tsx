import style from "./service.module.css";

const Service = () => {
  const properties = [
    {
      type: "Industrial",
      img: "industrial.png",
      desc: "Industrial development is our main line of business. We do Factory Construction, Warehouse and others",
    },
    {
      type: "Commercial",
      img: "commercial.png",
      desc: "Our experience building in the Commercial field includes Showrooms, Supermalls and Office Buildings",
    },
    {
      type: "Resedential",
      img: "resedential.png",
      desc: " Residential development is the beginning that has shaped us to this day. Our development includes Houses & Apartments",
    },
  ];
  return (
    <div className={style.container} id="services">
      <div className={style.upper}>
        <h3 className={style.heading}>Our Excellent Services</h3>
        <p className={style.para}>
          Check out our best service you can possibly orders in building your
          company and don't forget to ask via our email or our customer service
          if you are interested in using our services
        </p>
      </div>
      <div className={style.lower}>
        {properties.map((item) => (
          <div className={style.wrapper}>
            <img className={style.img} src={item.img} alt="" />
            <h2 className={style.headings}>{item.type}</h2>
            <p className={style.desc}>{item.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Service;

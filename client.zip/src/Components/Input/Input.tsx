import style from "./input.module.css";

interface Props {
  type: string;
  placeholder: string;
  setname: React.Dispatch<React.SetStateAction<string>>;
}

const Input = (props: Props) => {
  const { type, placeholder, setname } = props;

  const handleChange = (e: any) => {
    setname(e.target.value);
  };

  return (
    <input
      className={style.input}
      type={type}
      placeholder={placeholder}
      onChange={(e) => handleChange(e)}
    />
  );
};

export default Input;

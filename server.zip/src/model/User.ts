import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    firstName: String,
    lastName: String,
    phoneNumber: String,
    address: String,
    userType: { type: String, enum: ['buyer', 'seller', 'agent', 'admin'] }
})

export const User = mongoose.model("users", userSchema);
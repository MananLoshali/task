import style from "./about.module.css";

const About = () => {
  return (
    <div className={style.container} id="about">
      <div className={style.right}>
        <div className={style.wrapper}>
          <h1 className={style.heading}>Our Story Who we are</h1>
          <p className={style.para}>
            Established in 1992, PT. Wahana Cipta operates as a General
            Contracting company with a footprint that we have planted throughout
            Indonesia. Initially, we focused on construction in the field of
            residential housing development in Jakarta. As the company grows,
            now we are present as a reliable...
          </p>
          <div className={style.inner_wrapper}>
            <button className={style.btn}>See more</button>
          </div>
        </div>
      </div>

      <div className={style.left}>
        <img className={style.img} src="home2.png" alt="" />
      </div>
    </div>
  );
};

export default About;

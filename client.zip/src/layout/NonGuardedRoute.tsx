import { Navigate, Outlet } from "react-router-dom";
import { useAppSelector } from "../store/store";

const NonGuardedRoute = () => {
  const isLoggedIn = useAppSelector((state) => state.user.token);

  return isLoggedIn ? <Navigate to="/" /> : <Outlet />;
};

export default NonGuardedRoute;

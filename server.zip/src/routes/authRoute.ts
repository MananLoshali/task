import express from "express"
import { register } from "../controllers/authControllers";
import passport from "../config/passport"
import jwt from "jsonwebtoken"


const SECRET_KEY = process.env.KEY || "secretkey";

const router = express.Router();

router.post("/register", register);


router.post("/login", (req, res, next) => {
    passport.authenticate("local", { session: false }, (err: any, user: any, info: any) => {
        if (err) {
            return res.status(500).json({ error: err })
        }
        if (!user) {
            return res.status(401).json({ msg: "Invalid email or password" })
        }
        const token = jwt.sign({ userId: user._id }, SECRET_KEY, { expiresIn: '1d' });
        return res.json({ token: token });
    })(req, res, next)
})

export default router;
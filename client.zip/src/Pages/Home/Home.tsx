import Collection from "../../Components/Collection/Collection";
import About from "../../Components/About/About";
import Client from "../../Components/Clients/Client";
import Contact from "../../Components/Contact/Contact";
import Header from "../../Components/Header/Header";
import News from "../../Components/News/News";
import Service from "../../Components/Services/Service";
import Speciality from "../../Components/Specialities/Speciality";
import Footer from "../../Components/Footer/Footer";
import { useRef } from "react";

const Home = () => {
  const scrollRef = useRef(null);

  return (
    <div>
      <Header />
      <Client />
      <Service />
      <Speciality />
      <Contact />
      <About />
      <News />
      <Collection />
      <Footer />
    </div>
  );
};

export default Home;

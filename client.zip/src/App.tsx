// import "./App.css";

import { Route, Routes } from "react-router-dom";
import Home from "./Pages/Home/Home";
import Login from "./Pages/Login/Login";
import Register from "./Pages/Register/Register";
import NonGuardedRoute from "./layout/NonGuardedRoute";
import GuardedRoute from "./layout/GuardedRoute";
import NotFound from "./Pages/NotFound";

function App() {
  return (
    <Routes>
      <Route element={<NonGuardedRoute />}>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Route>
      <Route element={<GuardedRoute />}>
        <Route path="/" element={<Home />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;

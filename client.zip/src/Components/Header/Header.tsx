import Body from "../Body/Body";
import Navbar from "../Navbar/Navbar";
import style from "./header.module.css";

const Header = () => {
  return (
    <div className={style.container} id="home">
      <Navbar />
      <Body />
    </div>
  );
};

export default Header;

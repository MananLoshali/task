import style from "./news.module.css";

const News = () => {
  const news = [
    {
      date: "12 Jan",
      topic: "Elements of Content in Epoxy Paint ",
      img: "item1.png",
      desc: "Epoxy paint and epoxy floor contractor. Have you heard the two terms? And what does that have to do with the construction of existing buildings? Epoxy itself is included in the type of resin... Read more",
    },
    {
      date: "12 Jan",
      topic: "5 Right Steps in Warehouse Planning and Construction",
      img: "item2.png",
      desc: "Planning the construction of a warehouse for both industrial, personal and other goods storage must be done carefully. When the planning is done properly, the construction is... Read more",
    },
    {
      date: "12 Jan",
      topic: "Elements of Content in Epoxy Paint ",
      img: "item3.png",
      desc: "Epoxy paint and epoxy floor contractor. Have you heard the two terms? And what does that have to do with the construction of existing buildings? Epoxy itself is included in the type of resin... Read more",
    },
  ];
  return (
    <div className={style.container} id="articles">
      <h1 className={style.heading}>News & Update</h1>
      <div className={style.inner}>
        {news.map((item) => (
          <div className={style.wrapper}>
            <img src={item.img} alt="" />
            <div className={style.wrap}>
              <p className={style.date}>{item.date}</p>
              <p className={style.topic}>{item.topic}</p>
            </div>
            <p className={style.para}>{item.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default News;

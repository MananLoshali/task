import style from "./button.module.css";

interface Props {
  type: string;
}

const Button = (props: Props) => {
  const { type } = props;
  return <button className={style.button}>{type}</button>;
};

export default Button;

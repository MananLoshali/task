import style from "./client.module.css";

const Client = () => {
  const clients = [
    { img: "client1.png" },
    { img: "client2.png" },
    { img: "client3.png" },
    { img: "client4.png" },
    { img: "client5.png" },
  ];

  return (
    <div className={style.container}>
      {clients.map((item) => (
        <img className={style.image} src={item.img} />
      ))}
    </div>
  );
};

export default Client;
